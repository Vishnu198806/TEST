const express = require("express");
const mysql = require("mysql2");
const path = require("path");

const app = express();
const port = 3000;

// Middleware to parse JSON data
app.use(express.json());

// Serve static files (like login.html and signup.html) from the 'public' directory
app.use(express.static(path.join(__dirname, "public")));

// Root route to redirect to the login page
app.get("/", (req, res) => {
  res.redirect("/login.html"); // This will redirect users to the login page
});

// Create connection to MySQL database
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root", // Replace with your actual MySQL password
  database: "testdb", // Replace with your actual database name
});

// Connect to MySQL
db.connect((err) => {
  if (err) {
    console.error("Error connecting to the database:", err.message);
    return;
  }
  console.log("Connected to the MySQL database!");
});

// Signup route
app.post("/signup", (req, res) => {
  const { name, email, password } = req.body;

  const sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
  db.query(sql, [name, email, password], (err, result) => {
    if (err) {
      return res.status(500).json({
        message: "Error signing up. Please try again.",
        success: false,
      });
    }
    res.json({
      message: "User signed up successfully!",
      success: true,
      redirectToLogin: true,
    });
  });
});

// Login route
app.post("/login", (req, res) => {
  const { name, password } = req.body;

  const sql = "SELECT * FROM users WHERE name = ? AND password = ?";
  db.query(sql, [name, password], (err, results) => {
    if (err) {
      return res.status(500).json({ message: "Database error." });
    }
    if (results.length > 0) {
      res.json({ message: `Welcome back, ${name}!` });
    } else {
      res.json({
        message: "Invalid name or password. Please try again.",
        redirectToSignup: true,
      });
    }
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
